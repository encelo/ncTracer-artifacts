# Data files for the *ncTracer* project

## Icons

- The images in the `icons` folder have been created by Angelo Theodorou for the ncTracer project and are distributed under the terms of the *Creative Commons Attribution-ShareAlike 4.0 International License*
